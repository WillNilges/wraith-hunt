<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="chom" tilewidth="32" tileheight="32" tilecount="81" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_01.png"/>
 </tile>
 <tile id="1">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_02.png"/>
 </tile>
 <tile id="2">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_03.png"/>
 </tile>
 <tile id="3">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_04.png"/>
 </tile>
 <tile id="4">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_05.png"/>
 </tile>
 <tile id="5">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_06.png"/>
 </tile>
 <tile id="6">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_07.png"/>
 </tile>
 <tile id="7">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_08.png"/>
 </tile>
 <tile id="8">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_09.png"/>
 </tile>
 <tile id="9">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_10.png"/>
 </tile>
 <tile id="10">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_11.png"/>
 </tile>
 <tile id="11">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_12.png"/>
 </tile>
 <tile id="12">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_13.png"/>
 </tile>
 <tile id="13">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_14.png"/>
 </tile>
 <tile id="14">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_15.png"/>
 </tile>
 <tile id="15">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_16.png"/>
 </tile>
 <tile id="16">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_17.png"/>
 </tile>
 <tile id="17">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_18.png"/>
 </tile>
 <tile id="18">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_19.png"/>
 </tile>
 <tile id="19">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_20.png"/>
 </tile>
 <tile id="20">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_21.png"/>
 </tile>
 <tile id="21">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_22.png"/>
 </tile>
 <tile id="22">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_23.png"/>
 </tile>
 <tile id="23">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_24.png"/>
 </tile>
 <tile id="24">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_25.png"/>
 </tile>
 <tile id="25">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_26.png"/>
 </tile>
 <tile id="26">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_27.png"/>
 </tile>
 <tile id="27">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_28.png"/>
 </tile>
 <tile id="28">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_29.png"/>
 </tile>
 <tile id="29">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_30.png"/>
 </tile>
 <tile id="30">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_31.png"/>
 </tile>
 <tile id="31">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_32.png"/>
 </tile>
 <tile id="32">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_33.png"/>
 </tile>
 <tile id="33">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_34.png"/>
 </tile>
 <tile id="34">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_35.png"/>
 </tile>
 <tile id="35">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_36.png"/>
 </tile>
 <tile id="36">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_37.png"/>
 </tile>
 <tile id="37">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_38.png"/>
 </tile>
 <tile id="38">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_39.png"/>
 </tile>
 <tile id="39">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_40.png"/>
 </tile>
 <tile id="40">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_41.png"/>
 </tile>
 <tile id="41">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_42.png"/>
 </tile>
 <tile id="42">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_43.png"/>
 </tile>
 <tile id="43">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_44.png"/>
 </tile>
 <tile id="44">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_45.png"/>
 </tile>
 <tile id="45">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_46.png"/>
 </tile>
 <tile id="46">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_47.png"/>
 </tile>
 <tile id="47">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_48.png"/>
 </tile>
 <tile id="48">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_49.png"/>
 </tile>
 <tile id="49">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_50.png"/>
 </tile>
 <tile id="50">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_51.png"/>
 </tile>
 <tile id="51">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_52.png"/>
 </tile>
 <tile id="52">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_53.png"/>
 </tile>
 <tile id="53">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_54.png"/>
 </tile>
 <tile id="54">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_55.png"/>
 </tile>
 <tile id="55">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_56.png"/>
 </tile>
 <tile id="56">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_57.png"/>
 </tile>
 <tile id="57">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_58.png"/>
 </tile>
 <tile id="58">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_59.png"/>
 </tile>
 <tile id="59">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_60.png"/>
 </tile>
 <tile id="60">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_61.png"/>
 </tile>
 <tile id="61">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_62.png"/>
 </tile>
 <tile id="62">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_63.png"/>
 </tile>
 <tile id="63">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_64.png"/>
 </tile>
 <tile id="64">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_65.png"/>
 </tile>
 <tile id="65">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_66.png"/>
 </tile>
 <tile id="66">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_67.png"/>
 </tile>
 <tile id="67">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_68.png"/>
 </tile>
 <tile id="68">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_69.png"/>
 </tile>
 <tile id="69">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_70.png"/>
 </tile>
 <tile id="70">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_71.png"/>
 </tile>
 <tile id="71">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_72.png"/>
 </tile>
 <tile id="72">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_73.png"/>
 </tile>
 <tile id="73">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_74.png"/>
 </tile>
 <tile id="74">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_75.png"/>
 </tile>
 <tile id="75">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_76.png"/>
 </tile>
 <tile id="76">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_77.png"/>
 </tile>
 <tile id="77">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_78.png"/>
 </tile>
 <tile id="78">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_79.png"/>
 </tile>
 <tile id="79">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_80.png"/>
 </tile>
 <tile id="80">
  <image width="32" height="32" source="craftpix/industrial-zone/1 Tiles/IndustrialTile_81.png"/>
 </tile>
</tileset>
